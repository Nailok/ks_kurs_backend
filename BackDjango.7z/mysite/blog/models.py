from django.db import models


class Client(models.Model):
    name = models.CharField(max_length=10, null=True, verbose_name='Имя')
    updated = models.DateTimeField(auto_now_add=True, blank=True, null=True, verbose_name="Дата обновления")


class DataTable(models.Model):
    firstname = models.CharField(max_length=20, null=True, verbose_name='Имя')
    lastname = models.CharField(max_length=20, null=True, verbose_name='Фамилия')
    address = models.TextField(null=True, verbose_name='Адрес')
    phone = models.CharField(max_length=20, null=True, verbose_name='Телефон')
    birthday = models.DateField(null=True, verbose_name='Дата рождения')
    gender = models.CharField(max_length=1, null=True, verbose_name='Пол')
    updated = models.DateTimeField(auto_now_add=True, blank=True, null=True, verbose_name="Дата обновления")


